/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000000614135290_3959061474_init();
    work_m_00000000000925127771_0791564622_init();
    work_m_00000000002019274305_0254784918_init();
    work_m_00000000002148110106_2444586083_init();
    work_m_00000000004243986630_0886308060_init();
    work_m_00000000002079059782_1783167462_init();
    work_m_00000000003716124988_4205961752_init();
    work_m_00000000003517296485_3579239659_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000003517296485_3579239659");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
