/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Yamin Yee/Documents/440/Lab/Lab5/FF_Reg/tb_processor.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static unsigned int ng3[] = {0U, 0U};
static unsigned int ng4[] = {1U, 0U};
static unsigned int ng5[] = {2U, 0U};
static unsigned int ng6[] = {4U, 0U};
static unsigned int ng7[] = {5U, 0U};
static unsigned int ng8[] = {7U, 0U};
static unsigned int ng9[] = {8U, 0U};
static unsigned int ng10[] = {11U, 0U};
static unsigned int ng11[] = {3U, 0U};
static unsigned int ng12[] = {4294967294U, 0U};
static unsigned int ng13[] = {4294967284U, 0U};
static unsigned int ng14[] = {1234U, 0U};
static unsigned int ng15[] = {4294965463U, 0U};
static unsigned int ng16[] = {4294966060U, 0U};
static unsigned int ng17[] = {48U, 0U};
static const char *ng18 = "%s %d";
static int ng19[] = {1769152570, 0, 1936028448, 0, 1948279649, 0, 544499059, 0, 1919247220, 0, 543387506, 0, 1914728294, 0, 1970102885, 0, 1751457902, 0, 8276, 0};



static void Always_36_0(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;

LAB0:    t1 = (t0 + 1536U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);

LAB4:    xsi_set_current_line(37, ng0);
    t2 = (t0 + 1436);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 828);
    t4 = (t2 + 36U);
    t5 = *((char **)t4);
    memset(t3, 0, 8);
    t6 = (t5 + 4);
    t7 = *((unsigned int *)t6);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t6) == 0)
        goto LAB6;

LAB8:    t12 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t12) = 1;

LAB9:    t13 = (t3 + 4);
    t14 = (t5 + 4);
    t15 = *((unsigned int *)t5);
    t16 = (~(t15));
    *((unsigned int *)t3) = t16;
    *((unsigned int *)t13) = 0;
    if (*((unsigned int *)t14) != 0)
        goto LAB11;

LAB10:    t21 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t21 & 1U);
    t22 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t22 & 1U);
    t23 = (t0 + 828);
    xsi_vlogvar_assign_value(t23, t3, 0, 0, 1);
    goto LAB2;

LAB6:    *((unsigned int *)t3) = 1;
    goto LAB9;

LAB11:    t17 = *((unsigned int *)t3);
    t18 = *((unsigned int *)t14);
    *((unsigned int *)t3) = (t17 | t18);
    t19 = *((unsigned int *)t13);
    t20 = *((unsigned int *)t14);
    *((unsigned int *)t13) = (t19 | t20);
    goto LAB10;

}

static void Initial_40_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;

LAB0:    t1 = (t0 + 1680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng0);

LAB4:    xsi_set_current_line(41, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 828);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(42, ng0);
    t2 = (t0 + 2164);
    *((int *)t2) = 1;
    t3 = (t0 + 1708);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 920);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(44, ng0);
    t2 = (t0 + 2172);
    *((int *)t2) = 1;
    t3 = (t0 + 1708);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(45, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 920);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB1;

}

static void Always_48_2(char *t0)
{
    char t5[8];
    char t30[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t31;

LAB0:    t1 = (t0 + 1824U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 2180);
    *((int *)t2) = 1;
    t3 = (t0 + 1852);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(49, ng0);

LAB5:    xsi_set_current_line(50, ng0);
    t4 = (t0 + 1724);
    xsi_process_wait(t4, 20000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(51, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng3)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB10;

LAB7:    if (t16 != 0)
        goto LAB9;

LAB8:    *((unsigned int *)t5) = 1;

LAB10:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB11;

LAB12:
LAB13:    xsi_set_current_line(55, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB9:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB10;

LAB11:    xsi_set_current_line(52, ng0);

LAB14:    xsi_set_current_line(53, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB13;

LAB15:    xsi_set_current_line(56, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng4)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB19;

LAB16:    if (t16 != 0)
        goto LAB18;

LAB17:    *((unsigned int *)t5) = 1;

LAB19:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB20;

LAB21:
LAB22:    xsi_set_current_line(60, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB24;
    goto LAB1;

LAB18:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB19;

LAB20:    xsi_set_current_line(57, ng0);

LAB23:    xsi_set_current_line(58, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB22;

LAB24:    xsi_set_current_line(61, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng5)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB28;

LAB25:    if (t16 != 0)
        goto LAB27;

LAB26:    *((unsigned int *)t5) = 1;

LAB28:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB29;

LAB30:
LAB31:    xsi_set_current_line(65, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB33;
    goto LAB1;

LAB27:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB28;

LAB29:    xsi_set_current_line(62, ng0);

LAB32:    xsi_set_current_line(63, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB31;

LAB33:    xsi_set_current_line(66, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng6)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB37;

LAB34:    if (t16 != 0)
        goto LAB36;

LAB35:    *((unsigned int *)t5) = 1;

LAB37:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB38;

LAB39:
LAB40:    xsi_set_current_line(70, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB42;
    goto LAB1;

LAB36:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB37;

LAB38:    xsi_set_current_line(67, ng0);

LAB41:    xsi_set_current_line(68, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB40;

LAB42:    xsi_set_current_line(71, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng7)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB46;

LAB43:    if (t16 != 0)
        goto LAB45;

LAB44:    *((unsigned int *)t5) = 1;

LAB46:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB47;

LAB48:
LAB49:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB51;
    goto LAB1;

LAB45:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB46;

LAB47:    xsi_set_current_line(72, ng0);

LAB50:    xsi_set_current_line(73, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB49;

LAB51:    xsi_set_current_line(76, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng8)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB55;

LAB52:    if (t16 != 0)
        goto LAB54;

LAB53:    *((unsigned int *)t5) = 1;

LAB55:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB56;

LAB57:
LAB58:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB60;
    goto LAB1;

LAB54:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB55;

LAB56:    xsi_set_current_line(77, ng0);

LAB59:    xsi_set_current_line(78, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB58;

LAB60:    xsi_set_current_line(81, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng9)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB64;

LAB61:    if (t16 != 0)
        goto LAB63;

LAB62:    *((unsigned int *)t5) = 1;

LAB64:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB65;

LAB66:
LAB67:    xsi_set_current_line(85, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB69;
    goto LAB1;

LAB63:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB64;

LAB65:    xsi_set_current_line(82, ng0);

LAB68:    xsi_set_current_line(83, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB67;

LAB69:    xsi_set_current_line(86, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng10)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB73;

LAB70:    if (t16 != 0)
        goto LAB72;

LAB71:    *((unsigned int *)t5) = 1;

LAB73:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB74;

LAB75:
LAB76:    xsi_set_current_line(90, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB78;
    goto LAB1;

LAB72:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB73;

LAB74:    xsi_set_current_line(87, ng0);

LAB77:    xsi_set_current_line(88, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB76;

LAB78:    xsi_set_current_line(91, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng11)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB82;

LAB79:    if (t16 != 0)
        goto LAB81;

LAB80:    *((unsigned int *)t5) = 1;

LAB82:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB83;

LAB84:
LAB85:    xsi_set_current_line(95, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB87;
    goto LAB1;

LAB81:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB82;

LAB83:    xsi_set_current_line(92, ng0);

LAB86:    xsi_set_current_line(93, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB85;

LAB87:    xsi_set_current_line(96, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng12)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB91;

LAB88:    if (t16 != 0)
        goto LAB90;

LAB89:    *((unsigned int *)t5) = 1;

LAB91:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB92;

LAB93:
LAB94:    xsi_set_current_line(100, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB96;
    goto LAB1;

LAB90:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB91;

LAB92:    xsi_set_current_line(97, ng0);

LAB95:    xsi_set_current_line(98, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB94;

LAB96:    xsi_set_current_line(101, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng3)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB100;

LAB97:    if (t16 != 0)
        goto LAB99;

LAB98:    *((unsigned int *)t5) = 1;

LAB100:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB101;

LAB102:
LAB103:    xsi_set_current_line(105, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB105;
    goto LAB1;

LAB99:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB100;

LAB101:    xsi_set_current_line(102, ng0);

LAB104:    xsi_set_current_line(103, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB103;

LAB105:    xsi_set_current_line(106, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng7)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB109;

LAB106:    if (t16 != 0)
        goto LAB108;

LAB107:    *((unsigned int *)t5) = 1;

LAB109:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB110;

LAB111:
LAB112:    xsi_set_current_line(110, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB114;
    goto LAB1;

LAB108:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB109;

LAB110:    xsi_set_current_line(107, ng0);

LAB113:    xsi_set_current_line(108, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB112;

LAB114:    xsi_set_current_line(111, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng4)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB118;

LAB115:    if (t16 != 0)
        goto LAB117;

LAB116:    *((unsigned int *)t5) = 1;

LAB118:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB119;

LAB120:
LAB121:    xsi_set_current_line(115, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB123;
    goto LAB1;

LAB117:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB118;

LAB119:    xsi_set_current_line(112, ng0);

LAB122:    xsi_set_current_line(113, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB121;

LAB123:    xsi_set_current_line(116, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng13)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB127;

LAB124:    if (t16 != 0)
        goto LAB126;

LAB125:    *((unsigned int *)t5) = 1;

LAB127:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB128;

LAB129:
LAB130:    xsi_set_current_line(120, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB132;
    goto LAB1;

LAB126:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB127;

LAB128:    xsi_set_current_line(117, ng0);

LAB131:    xsi_set_current_line(118, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB130;

LAB132:    xsi_set_current_line(121, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng14)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB136;

LAB133:    if (t16 != 0)
        goto LAB135;

LAB134:    *((unsigned int *)t5) = 1;

LAB136:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB137;

LAB138:
LAB139:    xsi_set_current_line(125, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB141;
    goto LAB1;

LAB135:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB136;

LAB137:    xsi_set_current_line(122, ng0);

LAB140:    xsi_set_current_line(123, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB139;

LAB141:    xsi_set_current_line(126, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng15)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB145;

LAB142:    if (t16 != 0)
        goto LAB144;

LAB143:    *((unsigned int *)t5) = 1;

LAB145:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB146;

LAB147:
LAB148:    xsi_set_current_line(130, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB150;
    goto LAB1;

LAB144:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB145;

LAB146:    xsi_set_current_line(127, ng0);

LAB149:    xsi_set_current_line(128, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB148;

LAB150:    xsi_set_current_line(131, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng4)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB154;

LAB151:    if (t16 != 0)
        goto LAB153;

LAB152:    *((unsigned int *)t5) = 1;

LAB154:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB155;

LAB156:
LAB157:    xsi_set_current_line(135, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB159;
    goto LAB1;

LAB153:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB154;

LAB155:    xsi_set_current_line(132, ng0);

LAB158:    xsi_set_current_line(133, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB157;

LAB159:    xsi_set_current_line(136, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng16)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB163;

LAB160:    if (t16 != 0)
        goto LAB162;

LAB161:    *((unsigned int *)t5) = 1;

LAB163:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB164;

LAB165:
LAB166:    xsi_set_current_line(140, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB168;
    goto LAB1;

LAB162:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB163;

LAB164:    xsi_set_current_line(137, ng0);

LAB167:    xsi_set_current_line(138, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB166;

LAB168:    xsi_set_current_line(141, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng17)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB172;

LAB169:    if (t16 != 0)
        goto LAB171;

LAB170:    *((unsigned int *)t5) = 1;

LAB172:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB173;

LAB174:
LAB175:    xsi_set_current_line(145, ng0);
    t2 = (t0 + 1724);
    xsi_process_wait(t2, 20000LL);
    *((char **)t1) = &&LAB177;
    goto LAB1;

LAB171:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB172;

LAB173:    xsi_set_current_line(142, ng0);

LAB176:    xsi_set_current_line(143, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB175;

LAB177:    xsi_set_current_line(146, ng0);
    t2 = (t0 + 600U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng17)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB181;

LAB178:    if (t16 != 0)
        goto LAB180;

LAB179:    *((unsigned int *)t5) = 1;

LAB181:    t20 = (t5 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t5);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB182;

LAB183:
LAB184:    xsi_set_current_line(150, ng0);
    t2 = ((char*)((ng19)));
    t3 = (t0 + 1012);
    t4 = (t3 + 36U);
    t6 = *((char **)t4);
    xsi_vlogfile_write(1, 0, 0, ng18, 3, t0, (char)118, t2, 304, (char)119, t6, 32);
    goto LAB2;

LAB180:    t19 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB181;

LAB182:    xsi_set_current_line(147, ng0);

LAB185:    xsi_set_current_line(148, ng0);
    t26 = (t0 + 1012);
    t27 = (t26 + 36U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_signed_add(t30, 32, t28, 32, t29, 32);
    t31 = (t0 + 1012);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 32);
    goto LAB184;

}

static void Initial_153_3(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(153, ng0);

LAB4:    xsi_set_current_line(154, ng0);
    t2 = (t0 + 1868);
    xsi_process_wait(t2, 430000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(155, ng0);
    xsi_vlog_finish(1);
    goto LAB1;

}


extern void work_m_00000000001582063866_2905102280_init()
{
	static char *pe[] = {(void *)Always_36_0,(void *)Initial_40_1,(void *)Always_48_2,(void *)Initial_153_3};
	xsi_register_didat("work_m_00000000001582063866_2905102280", "isim/tb_processor_isim_beh.exe.sim/work/m_00000000001582063866_2905102280.didat");
	xsi_register_executes(pe);
}
