/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Yamin Yee/Documents/440/Lab/Lab5/FF_Reg/ImmGen.v";
static unsigned int ng1[] = {3U, 0U};
static unsigned int ng2[] = {1048575U, 0U};
static unsigned int ng3[] = {0U, 0U};
static unsigned int ng4[] = {35U, 0U};
static unsigned int ng5[] = {67U, 0U};
static unsigned int ng6[] = {23U, 0U};



static void Always_25_0(char *t0)
{
    char t4[8];
    char t16[8];
    char t17[8];
    char t27[8];
    char t28[8];
    char t31[8];
    char t57[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    int t15;
    char *t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t29;
    char *t30;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    char *t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    char *t56;

LAB0:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 1548);
    *((int *)t2) = 1;
    t3 = (t0 + 1380);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(26, ng0);

LAB5:    xsi_set_current_line(27, ng0);
    t5 = (t0 + 600U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t4 + 4);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t4) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t5) = t11;
    t12 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t12 & 127U);
    t13 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t13 & 127U);

LAB6:    t14 = ((char*)((ng1)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 7, t14, 7);
    if (t15 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng4)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 7, t2, 7);
    if (t15 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng5)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 7, t2, 7);
    if (t15 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng6)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 7, t2, 7);
    if (t15 == 1)
        goto LAB13;

LAB14:
LAB16:
LAB15:    xsi_set_current_line(32, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 828);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB17:    goto LAB2;

LAB7:    xsi_set_current_line(28, ng0);
    t18 = (t0 + 600U);
    t19 = *((char **)t18);
    memset(t17, 0, 8);
    t18 = (t17 + 4);
    t20 = (t19 + 4);
    t21 = *((unsigned int *)t19);
    t22 = (t21 >> 20);
    *((unsigned int *)t17) = t22;
    t23 = *((unsigned int *)t20);
    t24 = (t23 >> 20);
    *((unsigned int *)t18) = t24;
    t25 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t25 & 4095U);
    t26 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t26 & 4095U);
    t29 = (t0 + 600U);
    t30 = *((char **)t29);
    memset(t31, 0, 8);
    t29 = (t31 + 4);
    t32 = (t30 + 4);
    t33 = *((unsigned int *)t30);
    t34 = (t33 >> 31);
    t35 = (t34 & 1);
    *((unsigned int *)t31) = t35;
    t36 = *((unsigned int *)t32);
    t37 = (t36 >> 31);
    t38 = (t37 & 1);
    *((unsigned int *)t29) = t38;
    memset(t28, 0, 8);
    t39 = (t31 + 4);
    t40 = *((unsigned int *)t39);
    t41 = (~(t40));
    t42 = *((unsigned int *)t31);
    t43 = (t42 & t41);
    t44 = (t43 & 1U);
    if (t44 != 0)
        goto LAB18;

LAB19:    if (*((unsigned int *)t39) != 0)
        goto LAB20;

LAB21:    t46 = (t28 + 4);
    t47 = *((unsigned int *)t28);
    t48 = *((unsigned int *)t46);
    t49 = (t47 || t48);
    if (t49 > 0)
        goto LAB22;

LAB23:    t51 = *((unsigned int *)t28);
    t52 = (~(t51));
    t53 = *((unsigned int *)t46);
    t54 = (t52 || t53);
    if (t54 > 0)
        goto LAB24;

LAB25:    if (*((unsigned int *)t46) > 0)
        goto LAB26;

LAB27:    if (*((unsigned int *)t28) > 0)
        goto LAB28;

LAB29:    memcpy(t27, t55, 8);

LAB30:    xsi_vlogtype_concat(t16, 32, 32, 2U, t27, 20, t17, 12);
    t56 = (t0 + 828);
    xsi_vlogvar_assign_value(t56, t16, 0, 0, 32);
    goto LAB17;

LAB9:    xsi_set_current_line(29, ng0);
    t3 = (t0 + 600U);
    t5 = *((char **)t3);
    memset(t17, 0, 8);
    t3 = (t17 + 4);
    t6 = (t5 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 20);
    *((unsigned int *)t17) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 20);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t12 & 4095U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4095U);
    t7 = (t0 + 600U);
    t14 = *((char **)t7);
    memset(t31, 0, 8);
    t7 = (t31 + 4);
    t18 = (t14 + 4);
    t21 = *((unsigned int *)t14);
    t22 = (t21 >> 31);
    t23 = (t22 & 1);
    *((unsigned int *)t31) = t23;
    t24 = *((unsigned int *)t18);
    t25 = (t24 >> 31);
    t26 = (t25 & 1);
    *((unsigned int *)t7) = t26;
    memset(t28, 0, 8);
    t19 = (t31 + 4);
    t33 = *((unsigned int *)t19);
    t34 = (~(t33));
    t35 = *((unsigned int *)t31);
    t36 = (t35 & t34);
    t37 = (t36 & 1U);
    if (t37 != 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t19) != 0)
        goto LAB33;

LAB34:    t29 = (t28 + 4);
    t38 = *((unsigned int *)t28);
    t40 = *((unsigned int *)t29);
    t41 = (t38 || t40);
    if (t41 > 0)
        goto LAB35;

LAB36:    t42 = *((unsigned int *)t28);
    t43 = (~(t42));
    t44 = *((unsigned int *)t29);
    t47 = (t43 || t44);
    if (t47 > 0)
        goto LAB37;

LAB38:    if (*((unsigned int *)t29) > 0)
        goto LAB39;

LAB40:    if (*((unsigned int *)t28) > 0)
        goto LAB41;

LAB42:    memcpy(t27, t32, 8);

LAB43:    xsi_vlogtype_concat(t16, 32, 32, 2U, t27, 20, t17, 12);
    t39 = (t0 + 828);
    xsi_vlogvar_assign_value(t39, t16, 0, 0, 32);
    goto LAB17;

LAB11:    xsi_set_current_line(30, ng0);
    t3 = (t0 + 600U);
    t5 = *((char **)t3);
    memset(t17, 0, 8);
    t3 = (t17 + 4);
    t6 = (t5 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 7);
    *((unsigned int *)t17) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 7);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t12 & 31U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 31U);
    t7 = (t0 + 600U);
    t14 = *((char **)t7);
    memset(t27, 0, 8);
    t7 = (t27 + 4);
    t18 = (t14 + 4);
    t21 = *((unsigned int *)t14);
    t22 = (t21 >> 25);
    *((unsigned int *)t27) = t22;
    t23 = *((unsigned int *)t18);
    t24 = (t23 >> 25);
    *((unsigned int *)t7) = t24;
    t25 = *((unsigned int *)t27);
    *((unsigned int *)t27) = (t25 & 127U);
    t26 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t26 & 127U);
    t19 = (t0 + 600U);
    t20 = *((char **)t19);
    memset(t57, 0, 8);
    t19 = (t57 + 4);
    t29 = (t20 + 4);
    t33 = *((unsigned int *)t20);
    t34 = (t33 >> 31);
    t35 = (t34 & 1);
    *((unsigned int *)t57) = t35;
    t36 = *((unsigned int *)t29);
    t37 = (t36 >> 31);
    t38 = (t37 & 1);
    *((unsigned int *)t19) = t38;
    memset(t31, 0, 8);
    t30 = (t57 + 4);
    t40 = *((unsigned int *)t30);
    t41 = (~(t40));
    t42 = *((unsigned int *)t57);
    t43 = (t42 & t41);
    t44 = (t43 & 1U);
    if (t44 != 0)
        goto LAB44;

LAB45:    if (*((unsigned int *)t30) != 0)
        goto LAB46;

LAB47:    t39 = (t31 + 4);
    t47 = *((unsigned int *)t31);
    t48 = *((unsigned int *)t39);
    t49 = (t47 || t48);
    if (t49 > 0)
        goto LAB48;

LAB49:    t51 = *((unsigned int *)t31);
    t52 = (~(t51));
    t53 = *((unsigned int *)t39);
    t54 = (t52 || t53);
    if (t54 > 0)
        goto LAB50;

LAB51:    if (*((unsigned int *)t39) > 0)
        goto LAB52;

LAB53:    if (*((unsigned int *)t31) > 0)
        goto LAB54;

LAB55:    memcpy(t28, t46, 8);

LAB56:    xsi_vlogtype_concat(t16, 32, 32, 3U, t28, 20, t27, 7, t17, 5);
    t50 = (t0 + 828);
    xsi_vlogvar_assign_value(t50, t16, 0, 0, 32);
    goto LAB17;

LAB13:    xsi_set_current_line(31, ng0);
    t3 = ((char*)((ng3)));
    t5 = (t0 + 600U);
    t6 = *((char **)t5);
    memset(t17, 0, 8);
    t5 = (t17 + 4);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 12);
    *((unsigned int *)t17) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 12);
    *((unsigned int *)t5) = t11;
    t12 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t12 & 1048575U);
    t13 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t13 & 1048575U);
    xsi_vlogtype_concat(t16, 32, 32, 2U, t17, 20, t3, 12);
    t14 = (t0 + 828);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB17;

LAB18:    *((unsigned int *)t28) = 1;
    goto LAB21;

LAB20:    t45 = (t28 + 4);
    *((unsigned int *)t28) = 1;
    *((unsigned int *)t45) = 1;
    goto LAB21;

LAB22:    t50 = ((char*)((ng2)));
    goto LAB23;

LAB24:    t55 = ((char*)((ng3)));
    goto LAB25;

LAB26:    xsi_vlog_unsigned_bit_combine(t27, 20, t50, 20, t55, 20);
    goto LAB30;

LAB28:    memcpy(t27, t50, 8);
    goto LAB30;

LAB31:    *((unsigned int *)t28) = 1;
    goto LAB34;

LAB33:    t20 = (t28 + 4);
    *((unsigned int *)t28) = 1;
    *((unsigned int *)t20) = 1;
    goto LAB34;

LAB35:    t30 = ((char*)((ng2)));
    goto LAB36;

LAB37:    t32 = ((char*)((ng3)));
    goto LAB38;

LAB39:    xsi_vlog_unsigned_bit_combine(t27, 20, t30, 20, t32, 20);
    goto LAB43;

LAB41:    memcpy(t27, t30, 8);
    goto LAB43;

LAB44:    *((unsigned int *)t31) = 1;
    goto LAB47;

LAB46:    t32 = (t31 + 4);
    *((unsigned int *)t31) = 1;
    *((unsigned int *)t32) = 1;
    goto LAB47;

LAB48:    t45 = ((char*)((ng2)));
    goto LAB49;

LAB50:    t46 = ((char*)((ng3)));
    goto LAB51;

LAB52:    xsi_vlog_unsigned_bit_combine(t28, 20, t45, 20, t46, 20);
    goto LAB56;

LAB54:    memcpy(t28, t45, 8);
    goto LAB56;

}


extern void work_m_00000000002148110106_2444586083_init()
{
	static char *pe[] = {(void *)Always_25_0};
	xsi_register_didat("work_m_00000000002148110106_2444586083", "isim/tb_processor_isim_beh.exe.sim/work/m_00000000002148110106_2444586083.didat");
	xsi_register_executes(pe);
}
